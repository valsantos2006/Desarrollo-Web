//Array (arreglo) para las imagenes, aqui van las imagenes//

const imagenes =["https://images.unsplash.com/photo-1439886183900-e79ec0057170?q=80&w=1246&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                  "https://plus.unsplash.com/premium_photo-1666930230819-46c53f9e2e3f?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                  "https://images.unsplash.com/photo-1504006833117-8886a355efbf?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                  "https://plus.unsplash.com/premium_photo-1666363528954-51382581c51a?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                  "https://images.unsplash.com/photo-1501286353178-1ec881214838?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
  ];

//Selección de elementos//

const boton = document.getElementById("btn-cambiar");

const imageCard = document.getElementById("card-img");

const textoCard = document.getElementById("card-text");

//contador de imagenes//

let indice = 0;

//evento del click//

boton.addEventListener("click", ()=>
   {
  //hace que avance la foto//
  indice++;
  
  //el if es para cuando llegue al final regrese al inicio//
  
  if(indice >= imagenes.length){
    indice= 0;
    
  }
    
    //cambiar la imagen y el texto//
 imageCard.src = imagenes[indice];
textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;

  
});
